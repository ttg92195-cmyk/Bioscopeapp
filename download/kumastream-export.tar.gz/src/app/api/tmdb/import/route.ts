import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

const TMDB_API_KEY = '2e928cd76f7f5ae46f6e022f5dcc2612';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

// Rate limit helper - process in batches
const BATCH_SIZE = 5; // Process 5 items at a time
const DELAY_BETWEEN_BATCHES = 200; // 200ms delay between batches

function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fetchTMDBItem(id: number, type: string) {
  const endpoint = type === 'tv' ? `tv/${id}` : `movie/${id}`;
  const url = `${TMDB_BASE_URL}/${endpoint}?api_key=${TMDB_API_KEY}`;
  
  const response = await fetch(url);
  return response.json();
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { ids, type } = body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ error: 'IDs required' }, { status: 400 });
    }

    // Get existing TMDB IDs to avoid duplicates
    const existingMovies = await db.movie.findMany({
      where: {
        tmdbId: { in: ids },
        type: type === 'tv' ? 'series' : 'movie',
      },
      select: { tmdbId: true },
    });
    const existingTmdbIds = new Set(existingMovies.map(m => m.tmdbId));
    
    // Filter out already imported items
    const newIds = ids.filter(id => !existingTmdbIds.has(id));
    
    if (newIds.length === 0) {
      return NextResponse.json({
        success: true,
        imported: 0,
        skipped: ids.length,
        message: 'All items already imported',
      });
    }

    const imported: { id: string; title: string }[] = [];
    const failed: number[] = [];

    // Process in batches for better performance
    for (let i = 0; i < newIds.length; i += BATCH_SIZE) {
      const batch = newIds.slice(i, i + BATCH_SIZE);
      
      // Fetch all items in batch concurrently using Promise.allSettled
      const results = await Promise.allSettled(
        batch.map(id => fetchTMDBItem(id, type))
      );

      // Process results and create database entries
      const moviesToCreate: {
        tmdbId: number;
        title: string;
        overview: string;
        posterPath: string | null;
        backdropPath: string | null;
        releaseDate: string | null;
        rating: number;
        runtime: number | null;
        type: 'movie' | 'series';
        genres: string;
        seasons?: {
          seasonNumber: number;
          name: string;
          overview: string;
          posterPath: string | null;
          episodeCount: number;
        }[];
      }[] = [];

      for (let j = 0; j < results.length; j++) {
        const result = results[j];
        if (result.status === 'fulfilled' && result.value.id) {
          const data = result.value;
          const movieData = {
            tmdbId: data.id,
            title: data.title || data.name,
            overview: data.overview || '',
            posterPath: data.poster_path,
            backdropPath: data.backdrop_path,
            releaseDate: data.release_date || data.first_air_date,
            rating: data.vote_average || 0,
            runtime: data.runtime || data.episode_run_time?.[0] || null,
            type: type === 'tv' ? 'series' as const : 'movie' as const,
            genres: JSON.stringify(data.genres?.map((g: { name: string }) => g.name) || []),
          };

          if (type === 'tv' && data.seasons) {
            // Filter out Season 0 (Specials) - only include real seasons
            movieData.seasons = data.seasons
              .filter((season: { season_number: number }) => season.season_number > 0)
              .map((season: { 
                season_number: number; 
                name: string; 
                overview: string; 
                poster_path: string | null;
                episode_count: number;
              }) => ({
                seasonNumber: season.season_number,
                name: season.name || '',
                overview: season.overview || '',
                posterPath: season.poster_path,
                episodeCount: season.episode_count || 0,
              }));
          }

          moviesToCreate.push(movieData);
        } else {
          failed.push(batch[j]);
        }
      }

      // Create movies in database
      for (const movieData of moviesToCreate) {
        try {
          const { seasons, ...movieFields } = movieData;
          
          const movie = await db.movie.create({
            data: movieFields,
          });

          // Create seasons and episodes for TV shows
          if (type === 'tv' && seasons && seasons.length > 0) {
            for (const seasonData of seasons) {
              const season = await db.season.create({
                data: {
                  movieId: movie.id,
                  seasonNumber: seasonData.seasonNumber,
                  name: seasonData.name,
                  overview: seasonData.overview,
                  posterPath: seasonData.posterPath,
                },
              });

              // Batch create episodes
              if (seasonData.episodeCount > 0) {
                const episodes = Array.from({ length: seasonData.episodeCount }, (_, i) => ({
                  seasonId: season.id,
                  episodeNumber: i + 1,
                  title: `Episode ${i + 1}`,
                }));

                await db.episode.createMany({
                  data: episodes,
                });
              }
            }
          }

          imported.push({ id: movie.id, title: movie.title });
        } catch (dbError) {
          console.error(`Failed to create movie in DB:`, dbError);
        }
      }

      // Small delay between batches to avoid rate limiting
      if (i + BATCH_SIZE < newIds.length) {
        await delay(DELAY_BETWEEN_BATCHES);
      }
    }

    return NextResponse.json({
      success: true,
      imported: imported.length,
      skipped: existingTmdbIds.size,
      failed: failed.length,
      movies: imported,
    });
  } catch (error) {
    console.error('Import error:', error);
    return NextResponse.json({ error: 'Failed to import' }, { status: 500 });
  }
}
