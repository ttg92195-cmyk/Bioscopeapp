import { NextRequest, NextResponse } from 'next/server';

const TMDB_API_KEY = '2e928cd76f7f5ae46f6e022f5dcc2612';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_MAX_PAGES = 500; // TMDB's maximum page limit
const ITEMS_PER_PAGE = 20;
const BATCH_SIZE = 20; // Fetch 20 pages at a time to avoid rate limiting

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const type = searchParams.get('type') || 'movie';
  const year = searchParams.get('year');
  const genre = searchParams.get('genre');
  const count = parseInt(searchParams.get('count') || '50');
  const page = parseInt(searchParams.get('page') || '1');

  try {
    // Calculate how many pages we need
    const pagesToFetch = Math.ceil(count / ITEMS_PER_PAGE);
    // Limit to TMDB's maximum pages
    const totalPagesToFetch = Math.min(pagesToFetch, TMDB_MAX_PAGES);
    
    // Process in batches to avoid rate limiting
    const allResults: unknown[] = [];
    let totalPages = 0;
    
    // Fetch all pages in batches
    for (let batch = 0; batch < totalPagesToFetch; batch += BATCH_SIZE) {
      const batchEnd = Math.min(batch + BATCH_SIZE, totalPagesToFetch);
      const pagesInBatch = Array.from(
        { length: batchEnd - batch }, 
        (_, i) => page + batch + i
      );

      const fetchPromises = pagesInBatch.map(async (pageNum) => {
        const params = new URLSearchParams({
          api_key: TMDB_API_KEY,
          sort_by: 'popularity.desc',
          page: String(pageNum),
        });

        if (genre) {
          params.append('with_genres', genre);
        }

        if (year) {
          if (type === 'tv') {
            params.append('first_air_date_year', year);
          } else {
            params.append('primary_release_year', year);
          }
        }

        const endpoint = type === 'tv' ? 'tv' : 'movie';
        const url = `${TMDB_BASE_URL}/discover/${endpoint}?${params.toString()}`;
        
        try {
          const response = await fetch(url);
          return response.json();
        } catch {
          return { results: [], total_pages: 0 };
        }
      });

      const batchResults = await Promise.all(fetchPromises);

      for (const data of batchResults) {
        if (data.results) {
          allResults.push(...data.results);
        }
        if (data.total_pages) {
          totalPages = Math.max(totalPages, data.total_pages);
        }
      }
      
      // If we already have enough results, stop fetching
      if (allResults.length >= count) {
        break;
      }
    }

    // Limit to requested count
    const limitedResults = allResults.slice(0, count);

    return NextResponse.json({
      results: limitedResults,
      page,
      total_pages: totalPages,
      total_results: allResults.length,
      fetched_count: limitedResults.length,
    });
  } catch (error) {
    console.error('TMDB discover error:', error);
    return NextResponse.json({ error: 'Failed to discover' }, { status: 500 });
  }
}
