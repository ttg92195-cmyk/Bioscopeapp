import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    if (!id) {
      return NextResponse.json({ error: 'Missing id parameter' }, { status: 400 });
    }

    const movie = await db.movie.findUnique({
      where: { id },
      include: {
        downloadLinks: true,
        videoServers: true,
        seasons: {
          include: {
            episodes: {
              include: {
                downloadLinks: true,
                videoServers: true,
              },
              orderBy: {
                episodeNumber: 'asc',
              },
            },
          },
          orderBy: {
            seasonNumber: 'asc',
          },
        },
      },
    });

    if (!movie) {
      return NextResponse.json({ error: 'Movie not found' }, { status: 404 });
    }

    // Parse genres from JSON string
    const movieWithParsedData = {
      ...movie,
      genres: JSON.parse(movie.genres || '[]'),
    };

    return NextResponse.json({ movie: movieWithParsedData });
  } catch (error) {
    console.error('Get movie error:', error);
    return NextResponse.json({ error: 'Failed to get movie' }, { status: 500 });
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    const updateData: Record<string, unknown> = {};

    if (body.title !== undefined) updateData.title = body.title;
    if (body.overview !== undefined) updateData.overview = body.overview;
    if (body.quality !== undefined) updateData.quality = body.quality === 'none' ? null : body.quality;
    if (body.runtime !== undefined) updateData.runtime = body.runtime ? parseInt(body.runtime) : null;
    if (body.genres !== undefined) updateData.genres = JSON.stringify(body.genres);

    const movie = await db.movie.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json({ movie });
  } catch (error) {
    console.error('Update movie error:', error);
    return NextResponse.json({ error: 'Failed to update movie' }, { status: 500 });
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    await db.movie.delete({
      where: { id },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete movie error:', error);
    return NextResponse.json({ error: 'Failed to delete movie' }, { status: 500 });
  }
}
