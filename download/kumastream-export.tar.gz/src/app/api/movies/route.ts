import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const type = searchParams.get('type');
    const genre = searchParams.get('genre');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    const where: Record<string, unknown> = {};
    
    if (type) {
      where.type = type;
    }
    
    if (search) {
      where.title = {
        contains: search,
      };
    }

    const movies = await db.movie.findMany({
      where,
      include: {
        downloadLinks: true,
        seasons: {
          include: {
            episodes: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
      take: limit,
      skip: offset,
    });

    return NextResponse.json({ movies });
  } catch (error) {
    console.error('Get movies error:', error);
    return NextResponse.json({ error: 'Failed to get movies' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const movie = await db.movie.create({
      data: {
        title: body.title,
        overview: body.overview || '',
        posterPath: body.posterPath,
        backdropPath: body.backdropPath,
        releaseDate: body.releaseDate,
        rating: body.rating || 0,
        runtime: body.runtime,
        type: body.type || 'movie',
        genres: JSON.stringify(body.genres || []),
        quality: body.quality,
      },
    });

    return NextResponse.json({ movie });
  } catch (error) {
    console.error('Create movie error:', error);
    return NextResponse.json({ error: 'Failed to create movie' }, { status: 500 });
  }
}
