import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch video servers for a movie or episode
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const movieId = searchParams.get('movieId');
    const episodeId = searchParams.get('episodeId');

    if (movieId) {
      // Get movie video servers
      const servers = await db.movieVideoServer.findMany({
        where: { movieId },
        orderBy: { createdAt: 'asc' },
      });
      return NextResponse.json({ servers });
    }

    if (episodeId) {
      // Get episode video servers
      const servers = await db.videoServer.findMany({
        where: { episodeId },
        orderBy: { createdAt: 'asc' },
      });
      return NextResponse.json({ servers });
    }

    return NextResponse.json({ error: 'Missing movieId or episodeId' }, { status: 400 });
  } catch (error) {
    console.error('Get video servers error:', error);
    return NextResponse.json({ error: 'Failed to get video servers' }, { status: 500 });
  }
}

// POST - Create a new video server
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { movieId, episodeId, name, url } = body;

    if (!name || !url) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // For movies
    if (movieId) {
      const server = await db.movieVideoServer.create({
        data: {
          name,
          url,
          movieId,
        },
      });
      return NextResponse.json({ server });
    }

    // For episodes
    if (episodeId) {
      const server = await db.videoServer.create({
        data: {
          name,
          url,
          episodeId,
        },
      });
      return NextResponse.json({ server });
    }

    return NextResponse.json({ error: 'Missing movieId or episodeId' }, { status: 400 });
  } catch (error) {
    console.error('Create video server error:', error);
    return NextResponse.json({ error: 'Failed to create video server' }, { status: 500 });
  }
}

// PUT - Update a video server
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, name, url, type } = body; // type: 'movie' or 'episode'

    if (!id) {
      return NextResponse.json({ error: 'Missing server id' }, { status: 400 });
    }

    if (type === 'movie') {
      const server = await db.movieVideoServer.update({
        where: { id },
        data: { name, url },
      });
      return NextResponse.json({ server });
    } else {
      const server = await db.videoServer.update({
        where: { id },
        data: { name, url },
      });
      return NextResponse.json({ server });
    }
  } catch (error) {
    console.error('Update video server error:', error);
    return NextResponse.json({ error: 'Failed to update video server' }, { status: 500 });
  }
}

// DELETE - Delete a video server
export async function DELETE(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, type } = body; // type: 'movie' or 'episode'

    if (!id) {
      return NextResponse.json({ error: 'Missing server id' }, { status: 400 });
    }

    if (type === 'movie') {
      await db.movieVideoServer.delete({
        where: { id },
      });
    } else {
      await db.videoServer.delete({
        where: { id },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete video server error:', error);
    return NextResponse.json({ error: 'Failed to delete video server' }, { status: 500 });
  }
}
