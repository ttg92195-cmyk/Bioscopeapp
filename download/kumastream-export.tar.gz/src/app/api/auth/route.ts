import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { username, password } = body;

    // Check for admin credentials
    if (username === 'Admin8676' && password === 'Admin8676') {
      // Find or create admin user
      let user = await db.user.findUnique({
        where: { username: 'Admin8676' },
      });

      if (!user) {
        user = await db.user.create({
          data: {
            username: 'Admin8676',
            password: 'Admin8676',
            role: 'admin',
          },
        });
      }

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          username: user.username,
          role: user.role,
        },
      });
    }

    return NextResponse.json(
      { success: false, error: 'Invalid credentials' },
      { status: 401 }
    );
  } catch (error) {
    console.error('Login error:', error);
    return NextResponse.json({ error: 'Failed to login' }, { status: 500 });
  }
}
