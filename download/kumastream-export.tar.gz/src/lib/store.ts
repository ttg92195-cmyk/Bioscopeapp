import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Movie data interface
export interface StoredMovie {
  id: string;
  title: string;
  posterPath: string | null;
  backdropPath?: string | null;
  releaseDate?: string | null;
  rating?: number;
  type: 'movie' | 'series';
  quality?: string | null;
  viewedAt?: string; // For sorting in Recent
}

// User state
interface UserState {
  isAdmin: boolean;
  downloadEnabled: boolean;
  viewedMovies: StoredMovie[];
  bookmarkedMovies: StoredMovie[];
  login: (username: string, password: string) => boolean;
  logout: () => void;
  toggleDownload: () => void;
  addViewedMovie: (movie: StoredMovie) => void;
  isMovieViewed: (movieId: string) => boolean;
  addBookmark: (movie: StoredMovie) => void;
  removeBookmark: (movieId: string) => void;
  isBookmarked: (movieId: string) => boolean;
  getViewedMovieIds: () => string[];
  getBookmarkedMovieIds: () => string[];
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      isAdmin: false,
      downloadEnabled: false,
      viewedMovies: [],
      bookmarkedMovies: [],

      login: (username: string, password: string) => {
        if (username === 'Admin8676' && password === 'Admin8676') {
          set({ isAdmin: true });
          return true;
        }
        return false;
      },

      logout: () => {
        set({ isAdmin: false });
      },

      toggleDownload: () => {
        set((state) => ({ downloadEnabled: !state.downloadEnabled }));
      },

      addViewedMovie: (movie: StoredMovie) => {
        const { viewedMovies } = get();
        // Remove if exists (to update to front of list)
        const filtered = viewedMovies.filter((m) => m.id !== movie.id);
        // Add to front with timestamp
        set({ 
          viewedMovies: [
            { ...movie, viewedAt: new Date().toISOString() }, 
            ...filtered
          ] 
        });
      },

      isMovieViewed: (movieId: string) => {
        return get().viewedMovies.some((m) => m.id === movieId);
      },

      addBookmark: (movie: StoredMovie) => {
        const { bookmarkedMovies } = get();
        if (!bookmarkedMovies.some((m) => m.id === movie.id)) {
          set({ bookmarkedMovies: [movie, ...bookmarkedMovies] });
        }
      },

      removeBookmark: (movieId: string) => {
        set((state) => ({
          bookmarkedMovies: state.bookmarkedMovies.filter((m) => m.id !== movieId),
        }));
      },

      isBookmarked: (movieId: string) => {
        return get().bookmarkedMovies.some((m) => m.id === movieId);
      },

      getViewedMovieIds: () => {
        return get().viewedMovies.map((m) => m.id);
      },

      getBookmarkedMovieIds: () => {
        return get().bookmarkedMovies.map((m) => m.id);
      },
    }),
    {
      name: 'movie-user-storage',
    }
  )
);

// Settings state
interface SettingsState {
  primaryColor: string;
  siteName: string;
  setPrimaryColor: (color: string) => void;
  setSiteName: (name: string) => void;
}

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set) => ({
      primaryColor: '#E53935',
      siteName: 'Kumastream',

      setPrimaryColor: (color: string) => {
        set({ primaryColor: color });
      },

      setSiteName: (name: string) => {
        set({ siteName: name });
      },
    }),
    {
      name: 'movie-settings-storage',
    }
  )
);

// Sidebar state
interface SidebarState {
  isOpen: boolean;
  toggle: () => void;
  close: () => void;
  open: () => void;
}

export const useSidebarStore = create<SidebarState>((set) => ({
  isOpen: false,
  toggle: () => set((state) => ({ isOpen: !state.isOpen })),
  close: () => set({ isOpen: false }),
  open: () => set({ isOpen: true }),
}));
