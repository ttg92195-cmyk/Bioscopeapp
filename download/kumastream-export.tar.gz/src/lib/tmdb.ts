// TMDB API Configuration
const TMDB_API_KEY = '2e928cd76f7f5ae46f6e022f5dcc2612';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';
const TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p';

export interface TMDBMovie {
  id: number;
  title: string;
  name?: string; // For TV shows
  overview: string;
  poster_path: string | null;
  backdrop_path: string | null;
  release_date?: string;
  first_air_date?: string;
  vote_average: number;
  runtime?: number;
  episode_run_time?: number[];
  genres?: { id: number; name: string }[];
  genre_ids?: number[];
  seasons?: { season_number: number; name: string; episode_count: number; poster_path: string | null; overview: string }[];
  number_of_seasons?: number;
}

export interface TMDBSearchResponse {
  page: number;
  results: TMDBMovie[];
  total_pages: number;
  total_results: number;
}

export interface TMDBGenre {
  id: number;
  name: string;
}

// Get image URL
export function getImageUrl(path: string | null, size: 'w200' | 'w300' | 'w500' | 'w780' | 'original' = 'w500'): string | null {
  if (!path) return null;
  return `${TMDB_IMAGE_BASE}/${size}${path}`;
}

// Search movies
export async function searchMovies(query: string, page: number = 1): Promise<TMDBSearchResponse> {
  const url = `${TMDB_BASE_URL}/search/movie?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&page=${page}`;
  const response = await fetch(url);
  return response.json();
}

// Search TV shows
export async function searchTV(query: string, page: number = 1): Promise<TMDBSearchResponse> {
  const url = `${TMDB_BASE_URL}/search/tv?api_key=${TMDB_API_KEY}&query=${encodeURIComponent(query)}&page=${page}`;
  const response = await fetch(url);
  return response.json();
}

// Get movie details
export async function getMovieDetails(id: number): Promise<TMDBMovie> {
  const url = `${TMDB_BASE_URL}/movie/${id}?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Get TV show details
export async function getTVDetails(id: number): Promise<TMDBMovie> {
  const url = `${TMDB_BASE_URL}/tv/${id}?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Get TV season details
export async function getTVSeasonDetails(tvId: number, seasonNumber: number) {
  const url = `${TMDB_BASE_URL}/tv/${tvId}/season/${seasonNumber}?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Discover movies
export async function discoverMovies(params: {
  with_genres?: string;
  year?: number;
  page?: number;
  sort_by?: string;
}): Promise<TMDBSearchResponse> {
  const searchParams = new URLSearchParams({
    api_key: TMDB_API_KEY,
    page: String(params.page || 1),
    sort_by: params.sort_by || 'popularity.desc',
  });
  
  if (params.with_genres) searchParams.append('with_genres', params.with_genres);
  if (params.year) searchParams.append('primary_release_year', String(params.year));
  
  const url = `${TMDB_BASE_URL}/discover/movie?${searchParams.toString()}`;
  const response = await fetch(url);
  return response.json();
}

// Discover TV shows
export async function discoverTV(params: {
  with_genres?: string;
  year?: number;
  page?: number;
  sort_by?: string;
}): Promise<TMDBSearchResponse> {
  const searchParams = new URLSearchParams({
    api_key: TMDB_API_KEY,
    page: String(params.page || 1),
    sort_by: params.sort_by || 'popularity.desc',
  });
  
  if (params.with_genres) searchParams.append('with_genres', params.with_genres);
  if (params.year) searchParams.append('first_air_date_year', String(params.year));
  
  const url = `${TMDB_BASE_URL}/discover/tv?${searchParams.toString()}`;
  const response = await fetch(url);
  return response.json();
}

// Get movie genres
export async function getMovieGenres(): Promise<{ genres: TMDBGenre[] }> {
  const url = `${TMDB_BASE_URL}/genre/movie/list?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Get TV genres
export async function getTVGenres(): Promise<{ genres: TMDBGenre[] }> {
  const url = `${TMDB_BASE_URL}/genre/tv/list?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Popular movies
export async function getPopularMovies(page: number = 1): Promise<TMDBSearchResponse> {
  const url = `${TMDB_BASE_URL}/movie/popular?api_key=${TMDB_API_KEY}&page=${page}`;
  const response = await fetch(url);
  return response.json();
}

// Popular TV shows
export async function getPopularTV(page: number = 1): Promise<TMDBSearchResponse> {
  const url = `${TMDB_BASE_URL}/tv/popular?api_key=${TMDB_API_KEY}&page=${page}`;
  const response = await fetch(url);
  return response.json();
}

// Trending movies
export async function getTrendingMovies(): Promise<TMDBSearchResponse> {
  const url = `${TMDB_BASE_URL}/trending/movie/week?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Trending TV shows
export async function getTrendingTV(): Promise<TMDBSearchResponse> {
  const url = `${TMDB_BASE_URL}/trending/tv/week?api_key=${TMDB_API_KEY}`;
  const response = await fetch(url);
  return response.json();
}

// Genre ID mapping
export const GENRE_MAP: Record<number, string> = {
  28: 'Action',
  12: 'Adventure',
  16: 'Animation',
  35: 'Comedy',
  80: 'Crime',
  99: 'Documentary',
  18: 'Drama',
  10751: 'Family',
  14: 'Fantasy',
  36: 'History',
  27: 'Horror',
  10402: 'Music',
  9648: 'Mystery',
  10749: 'Romance',
  878: 'Science Fiction',
  53: 'Thriller',
  10752: 'War',
  37: 'Western',
  10759: 'Action & Adventure',
  10762: 'Kids',
  10763: 'News',
  10764: 'Reality',
  10765: 'Sci-Fi & Fantasy',
  10766: 'Soap',
  10767: 'Talk',
  10768: 'War & Politics',
};

export function getGenreNames(genreIds: number[]): string[] {
  return genreIds.map(id => GENRE_MAP[id]).filter(Boolean);
}
