'use client';

import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/Header';
import MobileNav from '../components/layout/MobileNav';
import { useSidebarStore, useUserStore, useSettingsStore } from '@/lib/store';
import { ArrowLeft, Wifi } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useRouter } from 'next/navigation';

export default function DownloadPage() {
  const { isOpen } = useSidebarStore();
  const { downloadEnabled, toggleDownload } = useUserStore();
  const { primaryColor } = useSettingsStore();
  const router = useRouter();

  return (
    <div className="min-h-screen bg-[#121212]">
      <Sidebar />
      <Header showSearch={false} />

      <main className="pt-4 pb-20">
        {/* Header */}
        <div className="flex items-center gap-4 px-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => router.back()}
            style={{ color: primaryColor }}
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-xl font-bold">Downloads</h1>
        </div>

        <div className="px-4">
          {/* Download Settings */}
          <div className="bg-[#1E1E1E] rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Wifi className="w-5 h-5 text-gray-400" />
                <div>
                  <Label className="text-white">Download with Wifi Only</Label>
                  <p className="text-xs text-gray-400">Save mobile data</p>
                </div>
              </div>
              <Switch />
            </div>
          </div>

          {/* All Download Link Toggle */}
          <div className="bg-[#1E1E1E] rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white">All Download Link</Label>
                <p className="text-xs text-gray-400 mt-1">
                  Enable to show download links in movie/series posts
                </p>
              </div>
              <Switch
                checked={downloadEnabled}
                onCheckedChange={toggleDownload}
                style={{ '--switch-bg': primaryColor } as React.CSSProperties}
              />
            </div>
          </div>

          {/* Status */}
          <div className="bg-[#1E1E1E] rounded-lg p-4 mb-4">
            <h3 className="font-semibold mb-2">Download Link Status</h3>
            {downloadEnabled ? (
              <div className="flex items-center gap-2 text-green-400">
                <div className="w-2 h-2 rounded-full bg-green-400" />
                <span className="text-sm">Download links are visible</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-yellow-400">
                <div className="w-2 h-2 rounded-full bg-yellow-400" />
                <span className="text-sm">Download links are hidden</span>
              </div>
            )}
          </div>

          {/* Downloaded List */}
          <div className="bg-[#1E1E1E] rounded-lg p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Downloaded List</h3>
              <span className="text-xs text-gray-400">Show select</span>
            </div>
            <div className="text-center py-8 text-gray-400">
              <p className="text-sm">No downloads yet</p>
              <p className="text-xs mt-1">Downloaded content will appear here</p>
            </div>
          </div>
        </div>
      </main>

      <MobileNav />
    </div>
  );
}
